#include<stdio.h>
#include<conio.h>
int main()
{
    int n;
    printf("enter n value");
    scanf("%d",&n);
    n>0?printf("it is positive"):printf("it is negative");
    getch();
}