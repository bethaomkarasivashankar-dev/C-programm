#include<stdio.h>
int main()
{
    float b,h,area;
    printf("enter b,h values");
    scanf("%f%f",&b,&h);
    area=0.5*b*h;
    printf("area=%f",area);
    return 0;
}