#include<stdio.h>
int main()
{
    float f,c;
    printf("enter c value");
    scanf("%f",&c);
    f=(1.8*c)+32;
    printf("farenhiet value=%f",f);
    return 0;
}
