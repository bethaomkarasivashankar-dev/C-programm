#include<stdio.h>
int main()
{
    static int x;
    printf("x=%d",x);
    return 0;
}