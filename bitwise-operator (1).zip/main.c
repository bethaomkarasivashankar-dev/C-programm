#include<stdio.h>
int main()
{
    int x,y,and,or;
    printf("enter x,y vaues");
    scanf("%d%d",&x,&y);
    and=x&y;
    printf("bitwise and=%d",and);
    or='xly';
    printf("\nbitwise or=%d",or);
    return 0;
}