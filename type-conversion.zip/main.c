#include<stdio.h>
#include<conio.h>
int main()
{
    int a=5,b=2;
    float c,d;
    c=a/b;
    printf("c=%f",c);
    d=(float)a/b;
    printf("\nd=%f",d);
    return 0;
}

