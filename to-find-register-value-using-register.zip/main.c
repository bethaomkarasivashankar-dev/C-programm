#include<stdio.h>
int main()
{
    register int x;
    printf("x=%d",x);
    return 0;
}