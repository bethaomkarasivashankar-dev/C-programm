#include<stdio.h>
int main()
{
    int s1,s2,s3,total,avg;
    printf("enter s1,s2,s3 values");
    scanf("%d%d%d",&s1,&s2,&s3);
    total=s1+s2+s3;
    avg=total/3;
    if(s1<35,s2<35,s3<35)
    printf("failed");
    else if(avg>=90)
    printf("A grade");
    else if(avg>=70)
    printf("B grade");
    else if(avg>=50)
    printf("C grade");
    else if(avg>=35)
    printf("D grade");
    else 
    printf("failed");
    return 0;
}
