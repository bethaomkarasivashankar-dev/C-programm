#include<stdio.h>
int main()
{
    auto int x;
    printf("x=%d",x);
    return 0;
}