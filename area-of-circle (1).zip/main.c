#include<stdio.h>
int main()
{
    float pi=3.14,r,area;
    printf("enter r value");
    scanf("%f",&r);
    area=03.14*r*r;
    printf("area=%f",area);
    return 0;
}