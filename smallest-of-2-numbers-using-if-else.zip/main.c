#include<stdio.h>
int main()
{
    int a,b;
    printf("enter a,b values");
    scanf("%d%d",&a,&b);
    if(a<b)
    printf("a is small");
    else
    printf("b is small");
    return 0;
}