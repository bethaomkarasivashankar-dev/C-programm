#include<stdio.h>
#include<math.h>
int main()
{
    int x,y;
    printf("enter any number");
    scanf("%d",&x);
    y=sqrt(x);
    printf("square root=%d",y);
    return 0;
}
