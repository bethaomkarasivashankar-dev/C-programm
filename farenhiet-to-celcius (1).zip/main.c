#include<stdio.h>
int main()
{
    float f,c;
    printf("enter f value");
    scanf("%d",&f);
    c=f-32/1.8;
    printf("cecius value=%f",c);
    return 0;
}