#include<stdio.h>
#include<stdlib.h>
int main()
{
    int *p;
    p=(int*)malloc(sizeof(int));
    *p=20;
    free(p);
    *p=10;
    printf("value = %d",*p);
    return 0;
}